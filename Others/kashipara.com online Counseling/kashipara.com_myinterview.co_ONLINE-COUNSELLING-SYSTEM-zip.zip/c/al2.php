<html>
<body>
<form name="pp" action="n01.php"  method="POST" >
 <center><table>
<tr><td><p><b>Enter_Rank:</b></p></td>
<td><input type="text" name="h1" value=""placeholder=" Enter Rank" required></td>
</tr>
<tr><td></td><td><input type="submit" value="SEARCH"></td>
<td><input type="button" value="LOGOUT" size="4" onclick="document.location='admin.php';"></td></tr>
</table></center>
</form>
</body>
</html>
