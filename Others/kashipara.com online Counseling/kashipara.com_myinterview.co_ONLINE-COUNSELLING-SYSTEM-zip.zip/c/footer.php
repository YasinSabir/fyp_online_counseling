<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
 <link rel="stylesheet" href="st0.css">
       <title>Title here!</title

</head>
<body>
  <table border="1" class="footer">
       <tr>
       <td><center><h1>Onlinecounsellingsystem&copy;2014-15</h1></center>
       </td></tr></table>
</body>
</html>
