p.t
{
    font-size:30px;
    background-color:white;
    font-style:Comic Sans MS;
    font-family:Comic Sans MS;
    font-weight:bold;
    color:#C00;
    first-letter:40px;
}
