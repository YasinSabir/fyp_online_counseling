
<html>
<link rel="stylesheet" href="st5.css">
<head>
       <title>Title here!</title>
       <h5 class="search">Search</h5>
       <link rel="stylesheet" href="button.css">
       <link rel="stylesheet" href="gmail.css">
</head>
<body>
<form name="f1" action="try1.php"  method="POST" >
<table class="search">
<tr><td class="search"><p>EnterCollageID:</p>
</td>
<td class="serach"><input type="text" name="se1" value=""></td>
</tr>
<tr><td></td>
<td>
<input type="submit" name="ee" size="4"  class="rc-button-red"  value="SEARCH">
</td>
</tr>
</body>
</html>
