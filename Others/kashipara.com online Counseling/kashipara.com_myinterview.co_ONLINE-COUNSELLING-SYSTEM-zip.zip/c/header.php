<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
       <title>Title here!</title>

</style>
</head>
<body>
<link rel="stylesheet" href="st.css">
<table class="1">
<tr><td class="a">Online counselling system</td></tr>
</table>
<table class="nav">
<tr><td class="b"><a href="h.php"><p class="h">Home</p></a></td>
<td class="b"><a href="C&A.php" target="_Blank"><p class="h">Counseling&admission</p></a></td>
<td class="b"><a href="r.php" target="_Blank"><p class="h">Reporting centers</p></a></td>
<td class="b"><a href="p.php" target="_Blank"><p class="h">Participating institues</p></a></td>
<td class="b"><a href="c.php" target="_Blank"><p class="h">Contact us</p></a></td>
</tr>
</table>
</body>
</html>
