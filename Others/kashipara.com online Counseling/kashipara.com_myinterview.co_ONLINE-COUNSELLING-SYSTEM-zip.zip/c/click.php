<?php
          function hello(){
              echo "Hello!!!joy";
          }
    ?>

<input type="button" name="Release" onclick="document.write('<?php hello() ?>');" value="Click to Release">
